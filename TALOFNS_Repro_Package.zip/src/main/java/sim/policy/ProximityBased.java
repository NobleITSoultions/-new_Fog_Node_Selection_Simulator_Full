package sim.policy;

import java.util.List;

import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class ProximityBased implements NodeSelectionPolicy {
    @Override public String name() { return "ProximityBased"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Choose node with minimal sampled RTT (proxy for physical proximity)
        double best = Double.POSITIVE_INFINITY;
        int bestIdx = 0;
        for(int i=0;i<nodes.size();i++){
            double rtt = qos.sampleRttMs(rng, nodes.get(i));
            if(rtt < best){
                best = rtt;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
