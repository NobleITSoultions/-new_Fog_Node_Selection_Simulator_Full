package sim.policy;

import java.util.List;

import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class DRLSelector implements NodeSelectionPolicy {
    @Override public String name() { return "DRLSelector"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Simulated "policy" as softmax over reward-like score.
        // Reward prefers high trust and low latency/load, with some exploration noise.
        double best = -1e18;
        int bestIdx = 0;
        for(int i=0;i<nodes.size();i++){
            FogNode n = nodes.get(i);
            double rttMs = qos.sampleRttMs(rng, n);
            double load = n.load(cfg.maxQueueLen);
            double reward = 0.55*n.trust + 0.35*(1.0/Math.max(1e-6, rttMs)) + 0.10*(1.0-Math.min(1.0, load));
            // exploration noise
            reward += rng.uniform(-0.02, 0.02);
            if(reward > best){
                best = reward;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
