package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class FuzzyLogicTrust implements NodeSelectionPolicy {
    @Override public String name() { return "FuzzyLogicTrust"; }

    private double fuzzyScore(double trust, double load){
        // Simple fuzzy-inspired rule surface:
        // high trust & low load => high score; penalize high load strongly
        double trustTerm = trust;
        double loadPenalty = 1.0 - Math.min(1.0, load);
        return 0.7 * trustTerm + 0.3 * loadPenalty;
    }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        double best = -1e18;
        int bestIdx = 0;
        for(int i=0;i<nodes.size();i++){
            FogNode n = nodes.get(i);
            double load = n.load(cfg.maxQueueLen);
            double score = fuzzyScore(n.trust, load);
            if(score > best){
                best = score;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
