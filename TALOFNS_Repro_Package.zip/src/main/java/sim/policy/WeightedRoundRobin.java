package sim.policy;

import java.util.ArrayList;
import java.util.List;

import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class WeightedRoundRobin implements NodeSelectionPolicy {
    private final List<Integer> wheel = new ArrayList<>();
    private int cursor = 0;
    private boolean built = false;

    @Override public String name() { return "WeightedRoundRobin"; }

    private void buildWheel(List<FogNode> nodes){
        // Weight by current trust (scaled) to approximate "weights"
        wheel.clear();
        for(int i=0;i<nodes.size();i++){
            int w = Math.max(1, (int)Math.round(nodes.get(i).trust * 10.0));
            for(int k=0;k<w;k++) wheel.add(i);
        }
        if(wheel.isEmpty()){
            for(int i=0;i<nodes.size();i++) wheel.add(i);
        }
        built = true;
        cursor = 0;
    }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        if(!built || wheel.size()==0) buildWheel(nodes);
        int idx = wheel.get(cursor % wheel.size());
        cursor = (cursor + 1) % wheel.size();
        // refresh wheel occasionally as trust changes
        if(cursor % 50 == 0) buildWheel(nodes);
        return idx;
    }
}
