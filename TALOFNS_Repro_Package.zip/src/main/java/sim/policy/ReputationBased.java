package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class ReputationBased implements NodeSelectionPolicy {
    @Override public String name() { return "ReputationBased"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Choose highest trust
        double best = -1.0;
        int bestIdx = 0;
        for(int i=0;i<nodes.size();i++){
            if(nodes.get(i).trust > best){
                best = nodes.get(i).trust;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
