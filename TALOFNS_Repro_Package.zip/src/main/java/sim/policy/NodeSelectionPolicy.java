package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public interface NodeSelectionPolicy {
    String name();
    // Return selected node index in nodes list, or -1 for reject/none
    int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec);
}
