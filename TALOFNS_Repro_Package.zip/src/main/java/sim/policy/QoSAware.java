package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class QoSAware implements NodeSelectionPolicy {
    @Override public String name() { return "QoSAware"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Weighted scoring over (normalized) latency, trust, and load
        // Prefer low latency, high trust, low load
        double best = -1e18;
        int bestIdx = 0;
        for(int i=0;i<nodes.size();i++){
            FogNode n = nodes.get(i);
            double rttMs = qos.sampleRttMs(rng, n);
            double load = n.load(cfg.maxQueueLen);
            double latencyScore = 1.0 / Math.max(1e-6, rttMs);
            double score = 0.5*latencyScore + 0.35*n.trust + 0.15*(1.0 - Math.min(1.0, load));
            if(score > best){
                best = score;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
