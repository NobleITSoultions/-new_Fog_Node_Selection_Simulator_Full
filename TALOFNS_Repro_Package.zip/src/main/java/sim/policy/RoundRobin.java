package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class RoundRobin implements NodeSelectionPolicy {
    private int cursor = 0;
    @Override public String name() { return "RoundRobin"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        int idx = cursor % nodes.size();
        cursor = (cursor + 1) % nodes.size();
        return idx;
    }
}
