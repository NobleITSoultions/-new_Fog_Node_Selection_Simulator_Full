package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class FirstFit implements NodeSelectionPolicy {
    @Override public String name() { return "FirstFit"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // first node that has queue capacity, else reject
        for (int i=0;i<nodes.size();i++){
            if (nodes.get(i).queue.size() < cfg.maxQueueLen) return i;
        }
        return -1;
    }
}
