package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class MCDM_AHP_TOPSIS implements NodeSelectionPolicy {
    @Override public String name() { return "AHP-TOPSIS"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Lightweight approximation: normalize criteria then compute closeness score
        // Criteria: latency (min), trust (max), load (min)
        double[] rtt = new double[nodes.size()];
        double[] trust = new double[nodes.size()];
        double[] load = new double[nodes.size()];

        double rttMin=Double.POSITIVE_INFINITY, rttMax=0;
        double tMin=Double.POSITIVE_INFINITY, tMax=0;
        double lMin=Double.POSITIVE_INFINITY, lMax=0;

        for(int i=0;i<nodes.size();i++){
            FogNode n = nodes.get(i);
            rtt[i] = qos.sampleRttMs(rng, n);
            trust[i] = n.trust;
            load[i] = n.load(cfg.maxQueueLen);

            rttMin = Math.min(rttMin, rtt[i]); rttMax = Math.max(rttMax, rtt[i]);
            tMin = Math.min(tMin, trust[i]);   tMax = Math.max(tMax, trust[i]);
            lMin = Math.min(lMin, load[i]);    lMax = Math.max(lMax, load[i]);
        }

        double best = -1e18;
        int bestIdx = 0;

        for(int i=0;i<nodes.size();i++){
            double nrtt = (rttMax==rttMin) ? 0.0 : (rtt[i]-rttMin)/(rttMax-rttMin); // 0 good
            double ntrust = (tMax==tMin) ? 1.0 : (trust[i]-tMin)/(tMax-tMin);      // 1 good
            double nload = (lMax==lMin) ? 0.0 : (load[i]-lMin)/(lMax-lMin);        // 0 good

            // Ideal best: (nrtt=0, ntrust=1, nload=0)
            double dPlus = Math.sqrt(Math.pow(nrtt-0.0,2) + Math.pow(ntrust-1.0,2) + Math.pow(nload-0.0,2));
            // Ideal worst: (1,0,1)
            double dMinus = Math.sqrt(Math.pow(nrtt-1.0,2) + Math.pow(ntrust-0.0,2) + Math.pow(nload-1.0,2));
            double closeness = dMinus / (dPlus + dMinus + 1e-12);
            if(closeness > best){
                best = closeness;
                bestIdx = i;
            }
        }

        return bestIdx;
    }
}
