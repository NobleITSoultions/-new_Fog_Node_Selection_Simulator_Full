package sim.policy;

import java.util.List;
import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class RandomSelection implements NodeSelectionPolicy {
    @Override public String name() { return "RandomSelection"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        return rng.randint(0, nodes.size()-1);
    }
}
