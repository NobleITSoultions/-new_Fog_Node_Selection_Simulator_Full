package sim.policy;

import java.util.ArrayList;
import java.util.List;

import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class TALOFNS_NoTrustFiltering implements NodeSelectionPolicy {
    @Override public String name() { return "TALOFNS_NoTrustFiltering"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Load filtering only (trust is not used to exclude)
        List<Integer> candidates = new ArrayList<>();
        for(int i=0;i<nodes.size();i++){
            FogNode n = nodes.get(i);
            double load = n.load(cfg.maxQueueLen);
            if(load <= cfg.loadMax) candidates.add(i);
        }
        if(candidates.isEmpty()) return -1;

        double best = -1e18;
        int bestIdx = -1;
        for(int idx: candidates){
            FogNode n = nodes.get(idx);
            double rttMs = qos.sampleRttMs(rng, n);
            double score = cfg.alpha*(1.0/Math.max(1e-6, rttMs)) + cfg.beta*n.trust; // still uses trust in score
            if(score > best){ best = score; bestIdx = idx; }
        }
        return bestIdx;
    }
}
