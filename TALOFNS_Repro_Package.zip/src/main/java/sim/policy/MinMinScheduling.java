package sim.policy;

import java.util.List;

import sim.Config;
import sim.QoSMonitor;
import sim.model.FogNode;
import sim.model.Task;
import sim.util.Rng;

public class MinMinScheduling implements NodeSelectionPolicy {
    @Override public String name() { return "MinMin"; }

    @Override
    public int selectNode(Task task, List<FogNode> nodes, Config cfg, QoSMonitor qos, Rng rng, double nowSec) {
        // Estimate completion time as (queue length + 1)*serviceTime + RTT
        double best = Double.POSITIVE_INFINITY;
        int bestIdx = -1;
        for (int i=0;i<nodes.size();i++){
            FogNode n = nodes.get(i);
            double rttMs = qos.sampleRttMs(rng, n);
            double serviceTimeSec = task.sizeMi / (cfg.serviceRateMiPerSecPerCore * n.vcpus);
            double eta = (n.queue.size()+1) * serviceTimeSec + rttMs/1000.0;
            if(eta < best){
                best = eta;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
