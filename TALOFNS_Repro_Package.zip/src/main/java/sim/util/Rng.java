package sim.util;

import java.util.Random;

public class Rng {
    private final Random r;

    public Rng(long seed) { this.r = new Random(seed); }

    public double uniform(double a, double b) {
        return a + (b - a) * r.nextDouble();
    }

    // Exponential inter-arrival time with rate lambda (>0)
    public double expInterarrival(double lambdaPerSec) {
        // inverse CDF: -ln(U)/lambda
        double u = Math.max(1e-12, r.nextDouble());
        return -Math.log(u) / lambdaPerSec;
    }

    public int randint(int loInclusive, int hiInclusive) {
        return loInclusive + r.nextInt(hiInclusive - loInclusive + 1);
    }

    public boolean bernoulli(double p) {
        return r.nextDouble() < p;
    }

    public Random raw() { return r; }
}
