package sim;

public class SimulationResult {
    public final String algorithm;
    public final int runId;
    public final double meanLatencyMs;
    public final double failureRatePct;
    public final double trustViolationRatePct;
    public final long tasksTotal;
    public final long tasksFailedOrRejected;
    public final long trustViolations;

    public SimulationResult(String algorithm, int runId, double meanLatencyMs, double failureRatePct, double trustViolationRatePct,
                            long tasksTotal, long tasksFailedOrRejected, long trustViolations) {
        this.algorithm = algorithm;
        this.runId = runId;
        this.meanLatencyMs = meanLatencyMs;
        this.failureRatePct = failureRatePct;
        this.trustViolationRatePct = trustViolationRatePct;
        this.tasksTotal = tasksTotal;
        this.tasksFailedOrRejected = tasksFailedOrRejected;
        this.trustViolations = trustViolations;
    }
}
