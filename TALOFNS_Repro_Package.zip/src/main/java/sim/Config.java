package sim;

public class Config {
    // Paper-aligned defaults
    public int numFogNodes = 6;
    public double simulationSeconds = 3600.0;      // 1 hour
    public double arrivalRatePerSecond = 200.0 / 60.0;  // 200 tasks per minute
    public double rttMinMs = 1.0;
    public double rttMaxMs = 5.0;

    // Trust
    public double trustMinInit = 0.7;
    public double trustMaxInit = 1.0;
    public double trustThreshold = 0.7;     // θ
    public double trustMemory = 0.7;        // μ (paper example uses 0.7)

    // Load
    public double loadMax = 0.80;           // Lmax
    public double schedulingIntervalSec = 5.0;

    // TALOFNS weights (α latency, β trust), α+β=1
    public double alpha = 0.6;
    public double beta = 0.4;

    // Node hardware abstraction (homogeneous)
    public int vcpus = 4;
    public double ghz = 2.3;

    // Task size model
    public double taskSizeMinMi = 5.0;      // million instructions
    public double taskSizeMaxMi = 50.0;

    // Failure model (stochastic) - keeps simulation realistic
    public double baseFailureProb = 0.002;  // background failures independent of scheduling
    public double overloadFailureSlope = 0.60; // additional failure as load exceeds 1.0

    // Queue/CPU model
    public double serviceRateMiPerSecPerCore = 120.0; // abstract speed
    public int maxQueueLen = 200;                     // if exceeded, reject

    // Output
    public String outDir = "logs";
    public int runs = 5;
    public long masterSeed = 20260126L;

    public static String help() {
        return String.join(System.lineSeparator(),
            "TALOFNS Reproducibility Simulator",
            "",
            "Flags:",
            "  --out <dir>            Output directory (default: logs)",
            "  --runs <int>           Number of independent runs (default: 5)",
            "  --seed <long>          Master RNG seed (default: 20260126)",
            "  --durationSec <double> Simulation duration in seconds (default: 3600)",
            "  --lambdaPerMin <double>Arrival rate (tasks per minute) (default: 200)",
            "  --theta <double>       Trust threshold θ (default: 0.7)",
            "  --lmax <double>        Load threshold Lmax (default: 0.8)",
            "  --alpha <double>       TALOFNS α (latency weight) (default: 0.6)",
            "  --beta <double>        TALOFNS β (trust weight) (default: 0.4)"
        );
    }
}
