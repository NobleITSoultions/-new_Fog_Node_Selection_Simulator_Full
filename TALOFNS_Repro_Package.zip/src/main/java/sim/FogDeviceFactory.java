package sim;

import java.util.ArrayList;
import java.util.List;

import sim.model.FogNode;
import sim.util.Rng;

public class FogDeviceFactory {
    public static List<FogNode> createFogNodes(Config cfg, Rng rng) {
        List<FogNode> nodes = new ArrayList<>();
        for (int i=0; i<cfg.numFogNodes; i++) {
            double trustInit = rng.uniform(cfg.trustMinInit, cfg.trustMaxInit);
            FogNode n = new FogNode("fog-"+(i+1), cfg.vcpus, cfg.ghz, trustInit);
            nodes.add(n);
        }
        return nodes;
    }
}
