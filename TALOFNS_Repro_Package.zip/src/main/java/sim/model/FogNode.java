package sim.model;

import java.util.ArrayDeque;
import java.util.Deque;

public class FogNode {
    public final String id;
    public final int vcpus;
    public final double ghz;
    public double trust;   // [0,1]
    public final Deque<QueuedTask> queue = new ArrayDeque<>();
    public double busyUntil = 0.0;

    public FogNode(String id, int vcpus, double ghz, double trustInit) {
        this.id = id;
        this.vcpus = vcpus;
        this.ghz = ghz;
        this.trust = trustInit;
    }

    public static class QueuedTask {
        public final Task task;
        public final double startTime;
        public final double finishTime;
        public final boolean success;
        public QueuedTask(Task task, double startTime, double finishTime, boolean success) {
            this.task = task; this.startTime = startTime; this.finishTime = finishTime; this.success = success;
        }
    }

    // Simple utilization proxy in [0, +inf): queue length normalized
    public double load(int maxQueueLen) {
        return Math.min(2.0, (double) queue.size() / (double) Math.max(1, maxQueueLen));
    }
}
