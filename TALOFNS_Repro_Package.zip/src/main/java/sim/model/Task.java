package sim.model;

public class Task {
    public final long id;
    public final double arrivalTime;
    public final double sizeMi; // million instructions
    public Task(long id, double arrivalTime, double sizeMi) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.sizeMi = sizeMi;
    }
}
