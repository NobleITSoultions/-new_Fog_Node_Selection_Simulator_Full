package sim;

import sim.policy.NodeSelectionPolicy;

import java.io.File;
import java.io.FileWriter;
import java.util.*;

public class MainSimulation {

    public static void main(String[] args) throws Exception {
        Config cfg = new Config();
        boolean includeAblation = true;

        // Parse minimal args
        for(int i=0;i<args.length;i++){
            switch(args[i]){
                case "--help":
                    System.out.println(Config.help());
                    System.out.println("  --noAblation           Do not run ablation variants");
                    return;
                case "--out":
                    cfg.outDir = args[++i]; break;
                case "--runs":
                    cfg.runs = Integer.parseInt(args[++i]); break;
                case "--seed":
                    cfg.masterSeed = Long.parseLong(args[++i]); break;
                case "--durationSec":
                    cfg.simulationSeconds = Double.parseDouble(args[++i]); break;
                case "--lambdaPerMin":
                    cfg.arrivalRatePerSecond = Double.parseDouble(args[++i]) / 60.0; break;
                case "--theta":
                    cfg.trustThreshold = Double.parseDouble(args[++i]); break;
                case "--lmax":
                    cfg.loadMax = Double.parseDouble(args[++i]); break;
                case "--alpha":
                    cfg.alpha = Double.parseDouble(args[++i]); break;
                case "--beta":
                    cfg.beta = Double.parseDouble(args[++i]); break;
                case "--noAblation":
                    includeAblation = false; break;
                default:
                    // ignore unknown
            }
        }

        // Main benchmark set (paper: 12 algorithms incl. TALOFNS)
        List<String> algorithms = new ArrayList<>(Arrays.asList(
                "TALOFNS",
                "DRLSelector",
                "AHP-TOPSIS",
                "QoSAware",
                "MinMin",
                "FuzzyLogicTrust",
                "ReputationBased",
                "WeightedRoundRobin",
                "ProximityBased",
                "RoundRobin",
                "FirstFit",
                "RandomSelection"
        ));

        // Ablation variants (paper Table 4)
        if(includeAblation){
            algorithms.addAll(Arrays.asList(
                "TALOFNS_NoTrustFiltering",
                "TALOFNS_NoLoadFiltering",
                "TALOFNS_FixedWeights"
            ));
        }

        File outDir = new File(cfg.outDir);
        outDir.mkdirs();

        File summaryFile = new File(outDir, "summary_per_run.csv");
        try(FileWriter fw = new FileWriter(summaryFile)) {
            fw.write("algorithm,run_id,mean_latency_ms,failure_rate_pct,trust_violation_rate_pct,tasks_total,tasks_failed_or_rejected,trust_violations\n");

            Simulator sim = new Simulator();
            for(String alg : algorithms){
                for(int run=1; run<=cfg.runs; run++){
                    long seed = cfg.masterSeed + 1000L*run + alg.hashCode();
                    NodeSelectionPolicy policy = PolicySelector.byName(alg);

                    File rawFile = new File(outDir, "raw/" + alg + "/run_" + run + ".csv");
                    SimulationResult r = sim.runOnce(policy, cfg, run, seed, rawFile);

                    fw.write(String.format(Locale.US,
                            "%s,%d,%.6f,%.6f,%.6f,%d,%d,%d\n",
                            r.algorithm, r.runId, r.meanLatencyMs, r.failureRatePct, r.trustViolationRatePct,
                            r.tasksTotal, r.tasksFailedOrRejected, r.trustViolations
                    ));
                    System.out.printf(Locale.US, "[%s] run %d done: latency=%.3fms, failure=%.2f%%, trustViol=%.2f%%%n",
                            r.algorithm, r.runId, r.meanLatencyMs, r.failureRatePct, r.trustViolationRatePct);
                }
            }
        }

        System.out.println("Done. Summary written to: " + summaryFile.getAbsolutePath());
    }
}
