package sim;

import sim.policy.*;

public class PolicySelector {
    public static NodeSelectionPolicy byName(String name) {
        switch (name) {
            case "TALOFNS": return new TALOFNS();
            case "RandomSelection": return new RandomSelection();
            case "FirstFit": return new FirstFit();
            case "RoundRobin": return new RoundRobin();
            case "WeightedRoundRobin": return new WeightedRoundRobin();
            case "ProximityBased": return new ProximityBased();
            case "MinMin": return new MinMinScheduling();
            case "ReputationBased": return new ReputationBased();
            case "FuzzyLogicTrust": return new FuzzyLogicTrust();
            case "QoSAware": return new QoSAware();
            case "AHP-TOPSIS": return new MCDM_AHP_TOPSIS();
            case "DRLSelector": return new DRLSelector();
            // Ablations
            case "TALOFNS_NoTrustFiltering": return new TALOFNS_NoTrustFiltering();
            case "TALOFNS_NoLoadFiltering": return new TALOFNS_NoLoadFiltering();
            case "TALOFNS_FixedWeights": return new TALOFNS_FixedWeights();
            default: throw new IllegalArgumentException("Unknown policy: " + name);
        }
    }
}
