package sim;

import sim.model.FogNode;

public class TrustManager {
    private final double memory; // μ

    public TrustManager(double memory) { this.memory = memory; }

    public void updateTrust(FogNode node, boolean success) {
        double s = success ? 1.0 : 0.0;
        node.trust = memory * node.trust + (1.0 - memory) * s;
        // clamp
        node.trust = Math.max(0.0, Math.min(1.0, node.trust));
    }
}
