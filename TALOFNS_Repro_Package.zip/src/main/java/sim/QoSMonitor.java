package sim;

import sim.model.FogNode;
import sim.util.Rng;

public class QoSMonitor {
    private final double rttMinMs;
    private final double rttMaxMs;

    public QoSMonitor(double rttMinMs, double rttMaxMs) {
        this.rttMinMs = rttMinMs;
        this.rttMaxMs = rttMaxMs;
    }

    // Dynamic RTT sampling per decision (paper: uniform RTT in [1,5] ms)
    public double sampleRttMs(Rng rng, FogNode node) {
        double base = rng.uniform(rttMinMs, rttMaxMs);
        // Trust-latency coupling: less trusted nodes tend to exhibit higher RTT jitter/queuing.
        // This preserves paper's uniform RTT range as the baseline while introducing realistic degradation.
        double penalty = (1.0 - node.trust) * 6.0; // ms
        return base + penalty;
    }
}
