package sim;

import sim.model.FogNode;
import sim.model.Task;
import sim.policy.NodeSelectionPolicy;
import sim.util.Rng;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Simulator {

    public static class RawRow {
        public long taskId;
        public double arrivalTime;
        public double startTime;
        public double finishTime;
        public double latencyMs;
        public String nodeId;
        public double rttMs;
        public double trustAtAssign;
        public double loadAtAssign;
        public boolean assigned;
        public boolean rejected;
        public boolean failed;
        public boolean trustViolation;
        public String failureReason;
    }

    public SimulationResult runOnce(NodeSelectionPolicy policy, Config cfg, int runId, long seed, File rawOutFile) throws IOException {
        Rng rng = new Rng(seed);
        QoSMonitor qos = new QoSMonitor(cfg.rttMinMs, cfg.rttMaxMs);
        TrustManager trustManager = new TrustManager(cfg.trustMemory);

        List<FogNode> nodes = FogDeviceFactory.createFogNodes(cfg, rng);

        List<RawRow> rows = new ArrayList<>(15000);

        double t = 0.0;
        long taskCounter = 0;

        // We keep node queues with "virtual" service; for each node we store finish times of queued tasks.
        Map<String, Double> lastFinish = new HashMap<>();
        for(FogNode n: nodes) lastFinish.put(n.id, 0.0);

        while (t < cfg.simulationSeconds) {
            // Next arrival (Poisson process)
            double dt = rng.expInterarrival(cfg.arrivalRatePerSecond);
            t += dt;
            if (t > cfg.simulationSeconds) break;

            Task task = new Task(++taskCounter, t, rng.uniform(cfg.taskSizeMinMi, cfg.taskSizeMaxMi));

            // Update queue state for all nodes (remove completed tasks) before making a new scheduling decision
            for (FogNode n : nodes) {
                cleanupQueue(n, t);
            }

            int idx = policy.selectNode(task, nodes, cfg, qos, rng, t);

            RawRow row = new RawRow();
            row.taskId = task.id;
            row.arrivalTime = task.arrivalTime;
            row.assigned = (idx >= 0);
            row.rejected = false;
            row.failed = false;
            row.trustViolation = false;
            row.failureReason = "";

            if (idx < 0) {
                // No eligible node found / policy rejects
                row.rejected = true;
                row.failed = true;
                row.failureReason = "NO_ELIGIBLE_NODE";
                row.nodeId = "NONE";
                row.startTime = task.arrivalTime;
                row.finishTime = task.arrivalTime;
                row.latencyMs = 0.0;
                row.rttMs = 0.0;
                row.trustAtAssign = Double.NaN;
                row.loadAtAssign = Double.NaN;
                rows.add(row);
                continue;
            }

            FogNode node = nodes.get(idx);

            // Capacity reject if queue too long
            if (node.queue.size() >= cfg.maxQueueLen) {
                row.rejected = true;
                row.failed = true;
                row.failureReason = "QUEUE_FULL";
                row.nodeId = node.id;
                row.rttMs = 0.0;
                row.trustAtAssign = node.trust;
                row.loadAtAssign = node.load(cfg.maxQueueLen);
                row.trustViolation = (node.trust < cfg.trustThreshold);
                rows.add(row);
                continue;
            }

            // Sample RTT for actual execution latency component
            double rttMs = qos.sampleRttMs(rng, node);
            row.rttMs = rttMs;

            double trustAtAssign = node.trust;
            double loadAtAssign = node.load(cfg.maxQueueLen);
            row.trustAtAssign = trustAtAssign;
            row.loadAtAssign = loadAtAssign;
            row.trustViolation = (trustAtAssign < cfg.trustThreshold);

            // Service time (sec) depends on size and cores
            double serviceTime = task.sizeMi / (cfg.serviceRateMiPerSecPerCore * node.vcpus);
            // Trust-performance coupling: less trusted nodes may be slower (e.g., contention/anomalies)
            serviceTime *= (1.0 + (1.0 - trustAtAssign) * 0.5);

            // Queueing: start at max(arrival, lastFinish)
            double start = Math.max(task.arrivalTime, lastFinish.get(node.id));
            double finish = start + serviceTime + (rttMs / 1000.0); // include RTT in completion time

            // Update last finish
            lastFinish.put(node.id, finish);

            // Failure probability increases if overloaded and/or trust low
            double overload = Math.max(0.0, loadAtAssign - 1.0);
            double pFail = cfg.baseFailureProb + cfg.overloadFailureSlope * overload;
            if (trustAtAssign < cfg.trustThreshold) {
                // nodes below threshold are more likely to be unreliable
                pFail += 0.03;
            }
            pFail = Math.min(0.95, Math.max(0.0, pFail));
            boolean success = !rng.bernoulli(pFail);

            row.nodeId = node.id;
            row.startTime = start;
            row.finishTime = finish;
            row.latencyMs = (finish - task.arrivalTime) * 1000.0; // end-to-end in ms
            row.failed = !success;
            if (!success) row.failureReason = "EXECUTION_FAILURE";

            // Maintain queue as bookkeeping (used for load proxy)
            node.queue.add(new FogNode.QueuedTask(task, start, finish, success));
            // Clean tasks that completed before current arrival time (to keep queue size realistic)
            cleanupQueue(node, task.arrivalTime);

            // Update trust after completion event
            trustManager.updateTrust(node, success);

            rows.add(row);
        }

        // Compute per-run metrics
        long total = rows.size();
        long failedOrRejected = rows.stream().filter(r -> r.failed || r.rejected).count();
        long trustViol = rows.stream().filter(r -> r.trustViolation && r.assigned && !r.rejected).count();

        double meanLatency = rows.stream()
                .filter(r -> r.assigned && !r.rejected)
                .mapToDouble(r -> r.latencyMs)
                .average()
                .orElse(0.0);

        double failureRate = (total == 0) ? 0.0 : (100.0 * failedOrRejected / (double) total);
        double trustViolationRate = (total == 0) ? 0.0 : (100.0 * trustViol / (double) total);

        // Write raw log
        writeRaw(rows, policy.name(), runId, rawOutFile);

        return new SimulationResult(policy.name(), runId, meanLatency, failureRate, trustViolationRate, total, failedOrRejected, trustViol);
    }

    private void cleanupQueue(FogNode node, double now) {
        while(!node.queue.isEmpty()){
            FogNode.QueuedTask q = node.queue.peekFirst();
            if (q.finishTime <= now) node.queue.pollFirst();
            else break;
        }
    }

    private void writeRaw(List<RawRow> rows, String alg, int runId, File file) throws IOException {
        file.getParentFile().mkdirs();
        try(FileWriter fw = new FileWriter(file)) {
            fw.write(String.join(",", Arrays.asList(
                    "algorithm","run_id","task_id","arrival_time_s","start_time_s","finish_time_s",
                    "latency_ms","assigned_node","rtt_ms","trust_at_assign","load_at_assign",
                    "assigned","rejected","failed","trust_violation","failure_reason"
            )));
            fw.write("\n");
            for(RawRow r: rows){
                fw.write(String.format(Locale.US,
                        "%s,%d,%d,%.6f,%.6f,%.6f,%.6f,%s,%.6f,%.6f,%.6f,%b,%b,%b,%b,%s\n",
                        alg, runId, r.taskId, r.arrivalTime, r.startTime, r.finishTime,
                        r.latencyMs, r.nodeId, r.rttMs, r.trustAtAssign, r.loadAtAssign,
                        r.assigned, r.rejected, r.failed, r.trustViolation, r.failureReason
                ));
            }
        }
    }
}
