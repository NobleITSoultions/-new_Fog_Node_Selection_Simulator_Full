#!/usr/bin/env python3
import argparse
from pathlib import Path
import pandas as pd
import numpy as np

def paired_ttest(x, y):
    # returns t, p (two-sided)
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    d = x - y
    n = d.size
    if n < 2:
        return np.nan, np.nan
    mean = d.mean()
    sd = d.std(ddof=1)
    if sd == 0:
        # If all diffs are zero, t is undefined; treat as p=1 if mean=0 else p~0
        return (np.inf if mean != 0 else 0.0), (0.0 if mean != 0 else 1.0)
    t = mean / (sd / np.sqrt(n))
    # p-value via scipy if available, else approximate with survival function of Student-t using mpmath
    try:
        from scipy import stats
        p = 2 * stats.t.sf(abs(t), df=n-1)
    except Exception:
        import mpmath as mp
        df = n-1
        # two-sided p via regularized incomplete beta
        # p = 2*(1-CDF(|t|))
        # Use mpmath quad for CDF approximation
        # Fallback: use mp.gammainc/ beta relationship
        # We'll approximate using mp.qf from mpmath isn't available; do numeric integration
        def pdf(u):
            return mp.gamma((df+1)/2)/(mp.sqrt(df*mp.pi)*mp.gamma(df/2))*(1+u**2/df)**(-(df+1)/2)
        cdf = 0.5 + mp.quad(pdf, [0, abs(t)])
        p = float(2*(1-cdf))
    return float(t), float(p)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--logdir", required=True, help="Directory containing summary_per_run.csv")
    ap.add_argument("--alpha", type=float, default=0.05)
    args = ap.parse_args()

    logdir = Path(args.logdir)
    summary = pd.read_csv(logdir/"summary_per_run.csv")

    # Mean ± std (sample std) per algorithm
    metrics = ["mean_latency_ms", "failure_rate_pct", "trust_violation_rate_pct"]
    table = summary.groupby("algorithm")[metrics].agg(["mean", "std"])
    table.columns = [f"{m}_{s}" for m, s in table.columns]
    out_table = logdir/"table_mean_std.csv"
    table.reset_index().to_csv(out_table, index=False)

    # Paired t-tests TALOFNS vs others for each metric using per-run paired values
    tal = summary[summary["algorithm"]=="TALOFNS"].sort_values("run_id")
    if tal.empty:
        raise SystemExit("No TALOFNS rows found in summary_per_run.csv")

    others = [a for a in sorted(summary["algorithm"].unique()) if a != "TALOFNS" and not a.startswith("TALOFNS_")]
    # Paper uses 11 baselines for Bonferroni in main table (excluding ablations)
    m_comparisons = len(others)
    alpha_b = args.alpha / max(1, m_comparisons)

    rows = []
    for alg in others:
        df = summary[summary["algorithm"]==alg].sort_values("run_id")
        merged = pd.merge(tal, df, on="run_id", suffixes=("_tal", "_alg"))
        for metric in metrics:
            t, p = paired_ttest(merged[f"{metric}_tal"], merged[f"{metric}_alg"])
            rows.append({
                "algorithm": alg,
                "metric": metric,
                "t_stat": t,
                "p_value": p,
                "bonferroni_alpha": alpha_b,
                "significant": bool(p < alpha_b)
            })

    tdf = pd.DataFrame(rows)
    out_t = logdir/"talofns_vs_all_ttests.csv"
    tdf.to_csv(out_t, index=False)

    report = logdir/"bonferroni_report.txt"
    with report.open("w", encoding="utf-8") as f:
        f.write(f"Paired t-tests (two-sided) comparing TALOFNS vs each baseline algorithm\n")
        f.write(f"Runs paired by run_id (n={tal['run_id'].nunique()})\n")
        f.write(f"Bonferroni correction: alpha={args.alpha} / {m_comparisons} = {alpha_b:.6g}\n\n")
        sig = tdf[tdf["significant"]==True]
        f.write(f"Significant comparisons: {len(sig)} / {len(tdf)}\n")
        f.write("See talofns_vs_all_ttests.csv for full results.\n")

    print("Wrote:")
    print(" -", out_table)
    print(" -", out_t)
    print(" -", report)

if __name__ == "__main__":
    main()
