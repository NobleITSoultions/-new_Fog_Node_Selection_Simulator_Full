#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTDIR="${1:-logs}"
RUNS="${2:-5}"
SEED="${3:-20260126}"

mkdir -p "$ROOT/target/classes"

# Compile
find "$ROOT/src/main/java" -name "*.java" > "$ROOT/target/sources.txt"
javac -source 11 -target 11 -d "$ROOT/target/classes" @"$ROOT/target/sources.txt"

# Jar
cat > "$ROOT/target/manifest.txt" <<'MAN'
Main-Class: sim.MainSimulation
MAN

jar cfm "$ROOT/target/talofns-repro-sim.jar" "$ROOT/target/manifest.txt" -C "$ROOT/target/classes" .

# Run
java -jar "$ROOT/target/talofns-repro-sim.jar" --out "$OUTDIR" --runs "$RUNS" --seed "$SEED"
echo "Done. Logs in: $OUTDIR"
